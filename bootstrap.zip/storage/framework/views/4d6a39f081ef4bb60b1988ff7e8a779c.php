<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div wire:snapshot="{&quot;data&quot;:[],&quot;memo&quot;:{&quot;id&quot;:&quot;eHe0w4dAVrZHV8M4AjZ5&quot;,&quot;name&quot;:&quot;filament.widgets.account-widget&quot;,&quot;path&quot;:&quot;water&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;children&quot;:[],&quot;scripts&quot;:[],&quot;assets&quot;:[],&quot;errors&quot;:[],&quot;locale&quot;:&quot;bn&quot;},&quot;checksum&quot;:&quot;e905c8a6142b0105d8229c11c7c4575afacade82dc33d0086d8a386936cc36e4&quot;}" wire:effects="{&quot;partials&quot;:[]}" wire:id="eHe0w4dAVrZHV8M4AjZ5" class="fi-wi-widget fi-grid-col lg:fi-grid-col-span fi-account-widget" style="--col-span-lg: span 1 / span 1;">
        <section x-data="{
            isCollapsed:  false ,
            }" class="fi-section">
        
            <div class="fi-section-content-ctn">
                <div class="fi-section-content">
                    <img class="fi-avatar fi-circular fi-size-lg fi-user-avatar" src="<?php echo e(asset('images/rickshaw.png')); ?>" alt="Avatar of Md Tanvir" loading="lazy">

                    <div class="fi-account-widget-main">
                        <h2 class="fi-account-widget-heading">
                            রিক্সার লাইসেন্স নবায়ন মেনেজমেন্ট সিস্টেম
                        </h2>

                        <h4 class="fi-account-widget-user-name" style="margin-left: 5.5rem; color: rgb(230, 143, 13); font-weight: 600;">
                        ঢাকা ক্যান্টনমেন্ট বোর্ড
                        </h4>
                    </div>

                    
                </div>
            
            </div>
        </section>
    </div>
   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\rickshawalicense\resources\views/filament/widgets/custom-info-widget.blade.php ENDPATH**/ ?>