<x-filament-panels::page>
    {{-- Page content --}}
    {{ $this->form }}
    {{ $this->table }}
</x-filament-panels::page>
