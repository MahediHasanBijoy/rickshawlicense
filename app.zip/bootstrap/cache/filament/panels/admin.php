<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.applicants.pages.create-applicant' => 'App\\Filament\\Resources\\Applicants\\Pages\\CreateApplicant',
    'app.filament.resources.applicants.pages.edit-applicant' => 'App\\Filament\\Resources\\Applicants\\Pages\\EditApplicant',
    'app.filament.resources.applicants.pages.list-applicants' => 'App\\Filament\\Resources\\Applicants\\Pages\\ListApplicants',
    'app.filament.resources.applicants.pages.view-applicant' => 'App\\Filament\\Resources\\Applicants\\Pages\\ViewApplicant',
    'app.filament.resources.application-settings.pages.create-application-setting' => 'App\\Filament\\Resources\\ApplicationSettings\\Pages\\CreateApplicationSetting',
    'app.filament.resources.application-settings.pages.edit-application-setting' => 'App\\Filament\\Resources\\ApplicationSettings\\Pages\\EditApplicationSetting',
    'app.filament.resources.application-settings.pages.list-application-settings' => 'App\\Filament\\Resources\\ApplicationSettings\\Pages\\ListApplicationSettings',
    'app.filament.resources.areas.pages.create-area' => 'App\\Filament\\Resources\\Areas\\Pages\\CreateArea',
    'app.filament.resources.areas.pages.edit-area' => 'App\\Filament\\Resources\\Areas\\Pages\\EditArea',
    'app.filament.resources.areas.pages.list-areas' => 'App\\Filament\\Resources\\Areas\\Pages\\ListAreas',
    'app.filament.resources.categories.pages.create-category' => 'App\\Filament\\Resources\\Categories\\Pages\\CreateCategory',
    'app.filament.resources.categories.pages.edit-category' => 'App\\Filament\\Resources\\Categories\\Pages\\EditCategory',
    'app.filament.resources.categories.pages.list-categories' => 'App\\Filament\\Resources\\Categories\\Pages\\ListCategories',
    'app.filament.resources.departments.pages.create-department' => 'App\\Filament\\Resources\\Departments\\Pages\\CreateDepartment',
    'app.filament.resources.departments.pages.edit-department' => 'App\\Filament\\Resources\\Departments\\Pages\\EditDepartment',
    'app.filament.resources.departments.pages.list-departments' => 'App\\Filament\\Resources\\Departments\\Pages\\ListDepartments',
    'app.filament.resources.designations.pages.create-designation' => 'App\\Filament\\Resources\\Designations\\Pages\\CreateDesignation',
    'app.filament.resources.designations.pages.edit-designation' => 'App\\Filament\\Resources\\Designations\\Pages\\EditDesignation',
    'app.filament.resources.designations.pages.list-designations' => 'App\\Filament\\Resources\\Designations\\Pages\\ListDesignations',
    'app.filament.resources.users.pages.create-user' => 'App\\Filament\\Resources\\Users\\Pages\\CreateUser',
    'app.filament.resources.users.pages.edit-user' => 'App\\Filament\\Resources\\Users\\Pages\\EditUser',
    'app.filament.resources.users.pages.list-users' => 'App\\Filament\\Resources\\Users\\Pages\\ListUsers',
    'app.filament.pages.application-report' => 'App\\Filament\\Pages\\ApplicationReport',
    'app.filament.pages.category-wise-application-report' => 'App\\Filament\\Pages\\CategoryWiseApplicationReport',
    'app.filament.pages.lottery-token-print' => 'App\\Filament\\Pages\\LotteryTokenPrint',
    'app.filament.pages.summery-report' => 'App\\Filament\\Pages\\SummeryReport',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.area-wise-approved-rickshaw' => 'App\\Filament\\Widgets\\AreaWiseApprovedRickshaw',
    'app.filament.widgets.category-wise-approved-rickshaw' => 'App\\Filament\\Widgets\\CategoryWiseApprovedRickshaw',
    'app.filament.widgets.category-wise-report' => 'App\\Filament\\Widgets\\CategoryWiseReport',
    'app.filament.widgets.custom-info-widget' => 'App\\Filament\\Widgets\\CustomInfoWidget',
    'app.filament.widgets.percentage-of-application' => 'App\\Filament\\Widgets\\PercentageOfApplication',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.auth.pages.edit-profile' => 'Filament\\Auth\\Pages\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.livewire.sidebar' => 'Filament\\Livewire\\Sidebar',
    'filament.livewire.simple-user-menu' => 'Filament\\Livewire\\SimpleUserMenu',
    'filament.livewire.topbar' => 'Filament\\Livewire\\Topbar',
    'filament.auth.pages.login' => 'Filament\\Auth\\Pages\\Login',
    'filament.auth.pages.password-reset.request-password-reset' => 'Filament\\Auth\\Pages\\PasswordReset\\RequestPasswordReset',
    'filament.auth.pages.password-reset.reset-password' => 'Filament\\Auth\\Pages\\PasswordReset\\ResetPassword',
    'bezhan-salleh.filament-shield.resources.roles.pages.list-roles' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ListRoles',
    'bezhan-salleh.filament-shield.resources.roles.pages.create-role' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\CreateRole',
    'bezhan-salleh.filament-shield.resources.roles.pages.view-role' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ViewRole',
    'bezhan-salleh.filament-shield.resources.roles.pages.edit-role' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\EditRole',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Pages\\ApplicationReport.php' => 'App\\Filament\\Pages\\ApplicationReport',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Pages\\CategoryWiseApplicationReport.php' => 'App\\Filament\\Pages\\CategoryWiseApplicationReport',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Pages\\LotteryTokenPrint.php' => 'App\\Filament\\Pages\\LotteryTokenPrint',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Pages\\SummeryReport.php' => 'App\\Filament\\Pages\\SummeryReport',
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Resources\\Applicants\\ApplicantResource.php' => 'App\\Filament\\Resources\\Applicants\\ApplicantResource',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Resources\\ApplicationSettings\\ApplicationSettingResource.php' => 'App\\Filament\\Resources\\ApplicationSettings\\ApplicationSettingResource',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Resources\\Areas\\AreaResource.php' => 'App\\Filament\\Resources\\Areas\\AreaResource',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Resources\\Categories\\CategoryResource.php' => 'App\\Filament\\Resources\\Categories\\CategoryResource',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Resources\\Departments\\DepartmentResource.php' => 'App\\Filament\\Resources\\Departments\\DepartmentResource',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Resources\\Designations\\DesignationResource.php' => 'App\\Filament\\Resources\\Designations\\DesignationResource',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Resources\\Users\\UserResource.php' => 'App\\Filament\\Resources\\Users\\UserResource',
    0 => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\RoleResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Widgets\\AreaWiseApprovedRickshaw.php' => 'App\\Filament\\Widgets\\AreaWiseApprovedRickshaw',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Widgets\\CategoryWiseApprovedRickshaw.php' => 'App\\Filament\\Widgets\\CategoryWiseApprovedRickshaw',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Widgets\\CategoryWiseReport.php' => 'App\\Filament\\Widgets\\CategoryWiseReport',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Widgets\\CustomInfoWidget.php' => 'App\\Filament\\Widgets\\CustomInfoWidget',
    'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament\\Widgets\\PercentageOfApplication.php' => 'App\\Filament\\Widgets\\PercentageOfApplication',
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\laravel\\rickshawalicense\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);