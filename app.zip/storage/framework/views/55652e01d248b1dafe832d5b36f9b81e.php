<?php
    use App\Helpers\Helper;
?>
<?php $__env->startSection('title'); ?>
    <title>আবেদন রিপোর্ট</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
    <div class="text-center">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" srcset="">
        <h4>ঢাকা ক্যান্টনমেন্ট বোর্ড</h4>
        <h6> আবেদন রিপোর্ট</h6>
        <?php if($year): ?>
        <h6 class="text-decoration-underline"><?php echo e(Helper::en2bn($year) . 'ইং'); ?></h6>
            
        <?php endif; ?>
        <?php if($area): ?>
            <h6 class="text-decoration-underline">এরিয়াঃ <?php echo e($area); ?></h6>
        <?php endif; ?>
        <?php if($category): ?>
            <h6 class="text-decoration-underline">ক্যাটাগরিঃ <?php echo e($category); ?></h6>
        <?php endif; ?>
        <?php if($application_status): ?>
            <h6 class="text-decoration-underline">স্ট্যাটাসঃ <?php echo e($application_status); ?></h6>
        <?php endif; ?>

    </div>
    <div>
        <table class="table table-striped table-bordered mt-4">
            <thead>
                <tr>
                    <th>ক্রমিক নং</th>
                    <th>আবেদনকারীর নাম</th>
                    <th>এলাকা</th>
                    <th>ক্যাটাগরি</th>
                    <th>আবেদনের তারিখ</th>
                    <th>স্ট্যাটাস</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(Helper::en2bn($key + 1)); ?></td>
                        <td><?php echo e($applicant->applicant_name); ?></td>
                        <td><?php echo e($applicant->area->area_name); ?></td>
                        <td><?php echo e($applicant->category->category_name); ?></td>
                        
                        <td><?php echo e(Helper::en2bn(date('d-m-Y', strtotime($applicant->applicaton_date)))); ?></td>
                        <td><?php echo e($applicant->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script>
        window.print();
        window.onafterprint = function () {
                window.close();
            };
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.report_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\rickshawalicense\resources\views\reports\application_report.blade.php ENDPATH**/ ?>