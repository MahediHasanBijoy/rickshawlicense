<?php $__env->startSection('main_content'); ?>
    <div class="card shadow border-0 rounded-4 mb-5" style="background: white;" id="applicantFormCard">
        <div class="card-header">
            <h3 class="text-center fw-bold">আপনার আবেদন সম্পাদন করুন</h3>
        </div>
        <div class="card-body">
            <div class="container mt-5">
                <form action="<?php echo e(route('applicant.update', $applicant->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="border p-4 rounded shadow-sm mb-2">
                        <h5 class="fw-bold mb-4">রুট ও ক্যাটাগরি নির্বাচন (Route & Category)</h5>
                        <div class=" mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                রুট <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check form-check">
                                    <input 
                                        type="radio"
                                        class="form-check-input <?php $__errorArgs = ['area_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="area_id"
                                        value="<?php echo e($area->id); ?>"
                                        id="area<?php echo e($area->id); ?>"
                                        <?php echo e(old('area_id', $applicant->area_id) == $area->id ? 'checked' : ''); ?>

                                    >
                                    <label class="form-check-label" for="area<?php echo e($area->id); ?>">
                                        <?php echo e($area->area_name); ?>

                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__errorArgs = ['area_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mb-3 align-items-center">
                            <label class=" col-form-label fw-bold">
                                ক্যাটাগরি <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check form-check ">
                                    <input 
                                        type="radio"
                                        class="form-check-input <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="category_id"
                                        value="<?php echo e($category->id); ?>"
                                        id="category<?php echo e($category->id); ?>"
                                        <?php echo e(old('category_id', $applicant->category_id) == $category->id ? 'checked' : ''); ?>

                                    >
                                    <label class="form-check-label" for="category<?php echo e($category->id); ?>">
                                        <?php echo e($category->category_name); ?>

                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                    </div>
                    <div class="border p-4 rounded shadow-sm mb-2">
                        <h5 class="fw-bold mb-4">ব্যক্তিগত তথ্য (Personal Information)</h5>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                আবেদনকারীর নাম <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="applicant_name" class="form-control form-control-lg <?php $__errorArgs = ['applicant_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('applicant_name', $applicant->applicant_name)); ?>">
                                <?php $__errorArgs = ['applicant_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class=" mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                পিতা/স্বামীর নাম<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="guardian_name" class="form-control form-control-lg <?php $__errorArgs = ['guardian_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('guardian_name', $applicant->guardian_name)); ?>">
                                <?php $__errorArgs = ['guardian_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mb-4 align-items-center">
                            <label class="col-form-label fw-bold">
                                বর্তমান ঠিকানা <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="present_address" class="form-control form-control-lg <?php $__errorArgs = ['present_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('present_address',$applicant->present_address)); ?>">
                                <?php $__errorArgs = ['present_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                স্থায়ী ঠিকানা <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="permanent_address" class="form-control form-control-lg <?php $__errorArgs = ['permanent_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="" value="<?php echo e(old('permanent_address',$applicant->permanent_address)); ?>">
                                <?php $__errorArgs = ['permanent_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                এন আইডি/জন্মনিবন্ধন নং <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="nid_no" class="form-control form-control-lg <?php $__errorArgs = ['nid_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('nid_no',$applicant->nid_no)); ?>">
                                <?php $__errorArgs = ['nid_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                ইমেইল
                            </label>
                            <div class="ms-5">
                                <input type="email" name="email" class="form-control form-control-lg" placeholder="" value="<?php echo e(old('email',$applicant->email)); ?>">
                            </div>
                        </div>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                মোবাইল<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="phone" class="form-control form-control-lg <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " placeholder="" value="<?php echo e(old('phone',$applicant->phone)); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="border p-4 rounded shadow-sm mb-2">
                        <h5 class="fw-bold mb-4">পে অর্ডারের বিবরণ (Pay Order Information)</h5>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                ব্যাংকের নাম<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="bank_name" class="form-control form-control-lg <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('bank_name',$applicant->bank_name)); ?>">
                                <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class=" mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                পে অর্ডার নং<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="pay_order_no" class="form-control form-control-lg <?php $__errorArgs = ['pay_order_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('pay_order_no',$applicant->pay_order_no)); ?>">
                                <?php $__errorArgs = ['pay_order_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mb-4 align-items-center">
                            <label class="col-form-label fw-bold">
                                পরিমান<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="amount" class="form-control form-control-lg <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('amount',$applicant->amount)); ?>" readonly>
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                পরিশোধের তারিখ<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="text" name="order_date" class="form-control form-control-lg <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="order_date" placeholder="" value="<?php echo e(old('order_date',\Carbon\Carbon::parse($applicant->order_date)->format('d-m-Y'))); ?>" readonly>
                                <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="border p-4 rounded shadow-sm mb-2">
                        <h5 class="fw-bold mb-4">প্রয়োজনীয় ডকুমেন্ট সংযুক্তকরণ</h5>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                আবেদনকারীর ছবি <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="file" name="applicant_image" class="form-control form-control-lg <?php $__errorArgs = ['applicant_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" id="applicant_image"> 
                                <?php $__errorArgs = ['applicant_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if($applicant->applicant_image): ?>
                                <?php
                                    $filePath = $applicant->applicant_image;
                                    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                                    $pdf_display = $extension=='pdf'?'':'display:none;';
                                    $img_display = $extension!='pdf'?'':'display:none;';
                                ?>
                                    <div class="my-2" id="applicant_preview_box" >
                                            <!-- PDF Preview -->
                                            <iframe 
                                                src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                                width="100%" 
                                                height="300" 
                                                style="border:1px solid #ccc;<?php echo e($pdf_display); ?>"
                                                id="applicant_pdf_preview">
                                            </iframe>
                                            <!-- Image Preview -->
                                            <img 
                                                src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                                alt="Applicant Image" 
                                                width="200"
                                                style="<?php echo e($img_display); ?>" 
                                                id="applicant_image_preview">
                                    </div>
                                <?php else: ?>
                                    <div class="my-2" id="applicant_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;display:none;"
                                            id="applicant_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="" 
                                            alt="Applicant Image" 
                                            width="200"
                                            style="display:none;" 
                                            id="applicant_image_preview">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class=" mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                নাগরিক সনদ<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="file" name="citizen_certificate_image" class="form-control form-control-lg <?php $__errorArgs = ['citizen_certificate_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" id="citizen_certificate_image">
                                <?php $__errorArgs = ['citizen_certificate_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if($applicant->citizen_certificate_image): ?>
                                <?php
                                    $filePath = $applicant->citizen_certificate_image;
                                    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                                    $pdf_display = $extension=='pdf'?'':'display:none;';
                                    $img_display = $extension!='pdf'?'':'display:none;';
                                ?>
                                    <div class="my-2" id="citizen_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;<?php echo e($pdf_display); ?>"
                                            id="citizen_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            alt="Citizen Image" 
                                            width="200" 
                                            style="<?php echo e($img_display); ?>"
                                            id="citizen_image_preview">
                                    </div>
                                <?php else: ?>
                                    <div class="my-2" id="citizen_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;display:none;"
                                            id="citizen_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="" 
                                            alt="Citizen Image" 
                                            width="200" 
                                            style="display:none;"
                                            id="citizen_image_preview">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class=" mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                ক্যাটাগরি প্রমানক<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="file" name="category_proof_image" class="form-control form-control-lg <?php $__errorArgs = ['category_proof_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" id="category_proof_image">
                                <?php $__errorArgs = ['category_proof_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if($applicant->category_proof_image): ?>
                                <?php
                                    $filePath = $applicant->category_proof_image;
                                    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                                    $pdf_display = $extension=='pdf'?'':'display:none;';
                                    $img_display = $extension!='pdf'?'':'display:none;';
                                ?>
                                    <div class="my-2" id="category_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;<?php echo e($pdf_display); ?>"
                                            id="category_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            alt="Applicant Image" 
                                            width="200" 
                                            style="<?php echo e($img_display); ?>"
                                            id="category_image_preview">
                                    </div>
                                <?php else: ?>
                                    <div class="my-2" id="category_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;display:none;"
                                            id="category_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="" 
                                            alt="Applicant Image" 
                                            width="200" 
                                            style="display:none;"
                                            id="category_image_preview">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-4 align-items-center">
                            <label class="col-form-label fw-bold">
                                এন আই ডি <span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="file" name="nid_image" class="form-control form-control-lg <?php $__errorArgs = ['nid_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" id="nid_image">
                                <?php $__errorArgs = ['nid_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if($applicant->nid_image): ?>
                                <?php
                                    $filePath = $applicant->nid_image;
                                    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                                    $pdf_display = $extension=='pdf'?'':'display:none;';
                                    $img_display = $extension!='pdf'?'':'display:none;';
                                ?>
                                    <div class="my-2" id="nid_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;<?php echo e($pdf_display); ?>"
                                            id="nid_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            alt="Nid Image" 
                                            width="200" 
                                            style="<?php echo e($img_display); ?>"
                                            id="nid_image_preview">
                                    </div>
                                <?php else: ?>
                                    <div class="my-2" id="nid_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;display:none;"
                                            id="nid_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="" 
                                            alt="Nid Image" 
                                            width="200" 
                                            style="display:none;"
                                            id="nid_image_preview">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="mb-3 align-items-center">
                            <label class="col-form-label fw-bold">
                                পে অর্ডারের ছবি<span class="text-danger">*</span>
                            </label>
                            <div class="ms-5">
                                <input type="file" name="py_order_image" class="form-control form-control-lg <?php $__errorArgs = ['py_order_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" id="py_order_image">
                                <?php $__errorArgs = ['py_order_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if($applicant->py_order_image): ?>
                                <?php
                                    $filePath = $applicant->py_order_image;
                                    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                                    $pdf_display = $extension=='pdf'?'':'display:none;';
                                    $img_display = $extension!='pdf'?'':'display:none;';
                                ?>
                                    <div class="my-2"  id="pay_order_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;<?php echo e($pdf_display); ?>"
                                            id="pay_order_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="<?php echo e(asset('storage/'.$filePath)); ?>" 
                                            alt="Pay Order Image" 
                                            width="200" 
                                            style="<?php echo e($img_display); ?>"
                                            id="pay_order_image_preview">
                                    </div>
                                <?php else: ?>
                                    <div class="my-2"  id="pay_order_preview_box" >
                                        <!-- PDF Preview -->
                                        <iframe 
                                            src="" 
                                            width="100%" 
                                            height="300" 
                                            style="border:1px solid #ccc;display:none;"
                                            id="pay_order_pdf_preview">
                                        </iframe>
                                        <!-- Image Preview -->
                                        <img 
                                            src="" 
                                            alt="Pay Order Image" 
                                            width="200" 
                                            style="display:none;"
                                            id="pay_order_image_preview">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- Submit Button -->
                    <div class="text-center mt-3">
                        <button type="submit" class="btn btn-success btn-lg px-5">জমা দিন</button>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary btn-lg px-5" >ফিরে যান</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        // image preview
        document.getElementById('applicant_image').addEventListener('change', function(e) {
            const [file] = e.target.files;
            if (file) {
                document.getElementById('applicant_preview_box').style.display = 'block';
                if (file.type.startsWith("image/")) {
                    document.getElementById('applicant_image_preview').style.display = "block";
                    document.getElementById('applicant_pdf_preview').style.display = "none";
                    document.getElementById('applicant_image_preview').src = URL.createObjectURL(file);
                }else if (file.type === "application/pdf") {
                    document.getElementById('applicant_image_preview').style.display = "none";
                    document.getElementById('applicant_pdf_preview').style.display = "block";
                    document.getElementById('applicant_pdf_preview').src = URL.createObjectURL(file);
                }
                //document.getElementById('applicant_image_preview').src = URL.createObjectURL(file);
            }
        });
        document.getElementById('citizen_certificate_image').addEventListener('change', function(e) {
            const [file] = e.target.files;
            if (file) {
                document.getElementById('citizen_preview_box').style.display = 'block';
                if (file.type.startsWith("image/")) {
                    document.getElementById('citizen_image_preview').style.display = "block";
                    document.getElementById('citizen_pdf_preview').style.display = "none";
                    document.getElementById('citizen_image_preview').src = URL.createObjectURL(file);
                }else if (file.type === "application/pdf") {
                    document.getElementById('citizen_image_preview').style.display = "none";
                    document.getElementById('citizen_pdf_preview').style.display = "block";
                    document.getElementById('citizen_pdf_preview').src = URL.createObjectURL(file);
                }
                //document.getElementById('citizen_image_preview').src = URL.createObjectURL(file);
            }
        });
        document.getElementById('category_proof_image').addEventListener('change', function(e) {
            const [file] = e.target.files;
            if (file) {
                document.getElementById('category_preview_box').style.display = 'block';
                if (file.type.startsWith("image/")) {
                    document.getElementById('category_image_preview').style.display = "block";
                    document.getElementById('category_pdf_preview').style.display = "none";
                    document.getElementById('category_image_preview').src = URL.createObjectURL(file);
                }else if (file.type === "application/pdf") {
                    document.getElementById('category_image_preview').style.display = "none";
                    document.getElementById('category_pdf_preview').style.display = "block";
                    document.getElementById('category_pdf_preview').src = URL.createObjectURL(file);
                }
                //document.getElementById('category_image_preview').src = URL.createObjectURL(file);
            }
        });
        document.getElementById('nid_image').addEventListener('change', function(e) {
            const [file] = e.target.files;
            if (file) {
                document.getElementById('nid_preview_box').style.display = 'block';
                if (file.type.startsWith("image/")) {
                    document.getElementById('nid_image_preview').style.display = "block";
                    document.getElementById('nid_pdf_preview').style.display = "none";
                    document.getElementById('nid_image_preview').src = URL.createObjectURL(file);
                }else if (file.type === "application/pdf") {
                    document.getElementById('nid_image_preview').style.display = "none";
                    document.getElementById('nid_pdf_preview').style.display = "block";
                    document.getElementById('nid_pdf_preview').src = URL.createObjectURL(file);
                }
                //document.getElementById('nid_image_preview').src = URL.createObjectURL(file);
            }
        });
        document.getElementById('py_order_image').addEventListener('change', function(e) {
            const [file] = e.target.files;
            if (file) {
                document.getElementById('pay_order_preview_box').style.display = 'block';
                if (file.type.startsWith("image/")) {
                    document.getElementById('pay_order_image_preview').style.display = "block";
                    document.getElementById('pay_order_pdf_preview').style.display = "none";
                    document.getElementById('pay_order_image_preview').src = URL.createObjectURL(file);
                }else if (file.type === "application/pdf") {
                    document.getElementById('pay_order_image_preview').style.display = "none";
                    document.getElementById('pay_order_pdf_preview').style.display = "block";
                    document.getElementById('pay_order_pdf_preview').src = URL.createObjectURL(file);
                }
                //document.getElementById('pay_order_image_preview').src = URL.createObjectURL(file);
            }
        });
    </script>
    <?php if($errors->any()): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let firstError = document.querySelector('.is-invalid');

            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\rickshawalicense\resources\views\applicant\edit.blade.php ENDPATH**/ ?>