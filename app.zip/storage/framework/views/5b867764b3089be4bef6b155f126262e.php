<div <?php echo e($attributes->class(['fi-btn-group'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\laravel\rickshawalicense\vendor\filament\support\resources\views\components\button\group.blade.php ENDPATH**/ ?>