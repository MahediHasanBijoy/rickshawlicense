
<?php
    use App\Helpers\Helper;
?>
<?php $__env->startSection('title'); ?>
    <title>সামারি রিপোর্ট</title>
<?php $__env->stopSection(); ?>
<?php
    use Rakibhstu\Banglanumber\NumberToBangla;
    $numto = new NumberToBangla();
?>
<?php $__env->startSection('main_content'); ?>
    <div class="text-center">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" srcset="">
        <h4>ঢাকা ক্যান্টনমেন্ট বোর্ড</h4>
        <h6> সামারি রিপোর্ট</h6>
        <?php if($year): ?>
        <h6 class="text-decoration-underline">বছরঃ <?php echo e(Helper::en2bn($year) . 'ইং'); ?></h6>
            
        <?php endif; ?>
        <?php if($area): ?>
            <h6 class="text-decoration-underline">এরিয়াঃ <?php echo e($area); ?></h6>
        <?php endif; ?>
        <?php if($category): ?>
            <h6 class="text-decoration-underline">ক্যাটাগরিঃ <?php echo e($category); ?></h6>
        <?php endif; ?>

    </div>
    <div>
        <table class="table table-striped table-bordered mt-4">
            <thead>
                <tr class="text-center align-middle">
                    <th rowspan="2">ক্রমিক নং</th>
                    <th rowspan="2">আবেদন নং</th>
                    <th rowspan="2">নাম</th>
                    <th rowspan="2">আবেদন ফি</th>
                    <th colspan="2">বার্ষিক ফি</th>
                    <th colspan="2">সিকিউরিটি ফি</th>
                    <th rowspan="2">মোট</th>
                </tr>
                <tr class="text-center">
                    <th>জমা</th>
                    <th>ফেরত</th>

                    <th>জমা</th>
                    <th>ফেরত</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><?php echo e(Helper::en2bn($key + 1)); ?></td>
                        <td><?php echo e(Helper::en2bn($payment->applicant->application_number )); ?></td>
                        <td><?php echo e($payment->applicant->applicant_name); ?></td>
                        <td><?php echo e($numto->bnCommaLakh($payment->fee)); ?></td>

                        <td><?php echo e($numto->bnCommaLakh($payment->yearly_fee)); ?></td>
                        <td><?php echo e($numto->bnCommaLakh($payment->yearly_fee_refund)); ?></td>

                        <td><?php echo e($numto->bnCommaLakh($payment->security_fee)); ?></td>
                        <td><?php echo e($numto->bnCommaLakh($payment->security_fee_refund)); ?></td>
                        <td><?php echo e($numto->bnCommaLakh($payment->total_paid)); ?></td>
                        
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td colspan="3">মোট</td>
                    <td><?php echo e($numto->bnCommaLakh($payments->sum('fee'))); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($payments->sum('yearly_fee'))); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($payments->sum('yearly_fee_refund'))); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($payments->sum('security_fee'))); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($payments->sum('security_fee_refund'))); ?></td>
                    <td><?php echo e($numto->bnCommaLakh($payments->sum('total_paid'))); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <script>
        window.print();
        window.onafterprint = function () {
                window.close();
            };
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.report_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\rickshawalicense\resources\views\reports\summery_application_report.blade.php ENDPATH**/ ?>