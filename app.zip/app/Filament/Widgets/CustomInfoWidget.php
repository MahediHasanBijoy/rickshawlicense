<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class CustomInfoWidget extends Widget
{
    protected static bool $isLazy=false;
    protected static ?int $sort=-1;
    protected string $view = 'filament.widgets.custom-info-widget';
}
